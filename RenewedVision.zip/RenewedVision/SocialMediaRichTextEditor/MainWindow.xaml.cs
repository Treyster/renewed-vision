﻿using FirstFloor.ModernUI.Windows.Controls;
using System;
using System.Collections.Generic;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.Text.RegularExpressions;

namespace SocialMediaRichTextEditor
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : ModernWindow
    {
        class Tag
        {
            public TextPointer StartPosition { get; set; }
            public TextPointer EndPosition { get; set; }
            public string Word { get; set; }
        }

        struct Pos
        {
            public int StartPos;
            public int EndPos;
        }

        public MainWindow()
        {
            InitializeComponent();
        }

        private void RichTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (input.Document == null)
                return;
            input.TextChanged -= RichTextBox_TextChanged;

            m_tags.Clear();

            // clear all the formats
            TextRange documentRange = new TextRange(input.Document.ContentStart, input.Document.ContentEnd);
            documentRange.ClearAllProperties();


            TextPointer navigator = input.Document.ContentStart;
            while (navigator.CompareTo(input.Document.ContentEnd) < 0)
            {
                TextPointerContext context = navigator.GetPointerContext(LogicalDirection.Backward);
                if (context == TextPointerContext.ElementStart && navigator.Parent is Run)
                {
                    text = ((Run)navigator.Parent).Text;
                    if (text != "")
                        CheckWordsInRun((Run)navigator.Parent);
                }
                navigator = navigator.GetNextContextPosition(LogicalDirection.Forward);
            }

            //only after all keywords are found, then we highlight them
            for (int i = 0; i < m_tags.Count; i++)
            {
                try
                {
                    TextRange range = new TextRange(m_tags[i].StartPosition, m_tags[i].EndPosition);
                    range.ApplyPropertyValue(TextElement.ForegroundProperty, new SolidColorBrush(Colors.Red));
                }
                catch { } // TODO
            }
            input.TextChanged += RichTextBox_TextChanged;
        }


        static string text;
        List<Tag> m_tags = new List<Tag>();
        static List<string> tags = new List<string>();
        static List<char> specials = new List<char>();

        internal void CheckWordsInRun(Run theRun) //do not hightlight keywords in this method
        {
            int sIndex = 0;  // Start index
            int eIndex = 0;  // End index

            for (int i = 0; i < text.Length; i++)
            {
                if (Char.IsWhiteSpace(text[i]))
                {
                    if (i > 0 && !(Char.IsWhiteSpace(text[i - 1])))
                    {
                        eIndex = i - 1;
                        string word = text.Substring(sIndex, eIndex - sIndex + 1);
                        Match m = Regex.Match(word, @"([\#\@][a-zA-Z]+\b)(?!;)");

                        if (m.Success)
                        {
                            Tag t = new Tag();
                            t.StartPosition = theRun.ContentStart.GetPositionAtOffset(sIndex, LogicalDirection.Forward);
                            t.EndPosition = theRun.ContentStart.GetPositionAtOffset(eIndex + 1, LogicalDirection.Backward);
                            t.Word = word;
                            m_tags.Add(t);
                        }
                    }
                    sIndex = i + 1;
                }
            }

            string lastWord = text.Substring(sIndex, text.Length - sIndex);
            Match m2 = Regex.Match(lastWord, @"([\#\@][a-zA-Z]+\b)(?!;)");

            if (m2.Success)
            {
                Tag t = new Tag();
                t.StartPosition = theRun.ContentStart.GetPositionAtOffset(sIndex, LogicalDirection.Forward);
                t.EndPosition = theRun.ContentStart.GetPositionAtOffset(text.Length, LogicalDirection.Backward);
                t.Word = lastWord;
                m_tags.Add(t);
            }
        }
    }
}
